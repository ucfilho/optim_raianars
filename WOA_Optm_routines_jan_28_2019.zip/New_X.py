
# atualiza a matriz de populacoes

import numpy as np
import Matriz_AC
import Enxame

def New_X(k,ITE,PAR,NPAR,MAX,MIN,Best,X):
  a=2*(k-ITE)/(1-ITE) # parametro que varia de 2 a zero linermente: gera espiral
  A,C=Matriz_AC.Matriz_AC(a,PAR,NPAR)# matriz da espiral e matrix aletoria range dobro
  Xrand=Enxame.Enxame(PAR,NPAR,MAX,MIN) #  sera utilizado para A>=1
  for j in range(PAR):
    for i in range(NPAR):
      l=np.random.random()*2 - 1 # valor entre [-1,1]
      p=np.random.random() # valor entre [0,1]
      if(p< 0.5):
        if(A[i,j]<1):
          D=abs(Best[j]*C[i,j]-X[i,j])
          X[i,j]=Best[j]-A[i,j]*D
        else: #if(A[i,j]<1):
          D=abs(Xrand[i,j]*C[i,j]-X[i,j])
          X[i,j]=Xrand[i,j]-A[i,j]*D
      else: #if(p< 0.5):
        D=abs(Best[j]-X[i,j])
        X[i,j]=D*np.exp(l*2)*np.cos(2*np.pi*l)+Best[j]
        
      if(X[i,j]> MAX[j]):
        X[i,j]=MAX[j]
      if(X[i,j]< MIN[j]):
        X[i,j]=MIN[j]
        
  return X

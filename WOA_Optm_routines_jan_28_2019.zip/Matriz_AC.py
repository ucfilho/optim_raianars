''' 
Matriz_AC 
  retorna matriz A decrescente q vai 2 a zero
  retorna matriz C
  A decrescente q vai 2 a zero
  C aleatoria q vai de 
'''
import numpy as np

def Matriz_AC(a,PAR,NPAR):
  A=np.zeros((NPAR, PAR))
  C=np.zeros((NPAR, PAR))
  for j in range(PAR):
    for i in range(NPAR):
      A[i,j]=a*(2*np.random.random()-1)
      C[i,j]=2*np.random.random()
  return A,C

import WOA

# inicializa as variaveis, executa o metdo e imprime os resultados
NPAR=200 #Baleias
ITE=50 #ITERACOES
PAR=2 #NUM DE PARAMETROS A SER OTIMIZADOS
MAX=[2,2] # MAXIMO DE CADA PARAMETRO
MIN=[-2,-2] # MINIMO DE CADA PARAMETRO

Best,ycal=WOA.WOA(ITE,PAR,NPAR,MAX,MIN)
print("Baleias=",NPAR,"      Iteracoes=",ITE,"   x=",Best,"       fobj=",ycal,"\n")

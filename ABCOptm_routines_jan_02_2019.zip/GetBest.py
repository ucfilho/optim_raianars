'''
Obtem a melhor escolha greedy search
'''
import Fun
import FOBJ
import numpy as np

def GetBest(x,xbest):
    ycal=FOBJ.FOBJ(x)
    best=np.argmin(ycal)
    yref=Fun.Fun(xbest)
    if(yref<ycal[best]):
        GBEST=xbest
    else:
        GBEST=x[best,]
    return GBEST
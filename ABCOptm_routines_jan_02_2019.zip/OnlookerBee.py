'''
onlooker bee phase
'''
import Fun
import PROB
import numpy as np

def OnlookerBee(xo,x):
    rows = xo.shape[0]
    cols = xo.shape[1]
    prob=PROB.PROB(x)
    best=np.argmax(prob)

    for i in range(rows):
        if(Fun.Fun(x[best,])<Fun.Fun(xo[i,])):
            xo[i,]=np.copy(x[best,])
    return xo
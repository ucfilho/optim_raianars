import numpy as np
from random import randint

import Fun
import ABCOPtim
import numpy as np



NPAR=30 #PARTICULAS
ITE=300 #ITERACOES
PAR=2 #NUM DE PARAMETROS A SER OTIMIZADOS
MAX=[2,2] # MAXIMO DE CADA PARAMETRO
MIN=[-2,-2] # MINIMO DE CADA PARAMETRO
ntrail=25 #numero de buscas ate abandonar uma fonte de alimento

for i in range(6):
    print("resolucao",i+1," ")
    xbest=ABCOPtim.ABC(ITE,PAR,ntrail,NPAR,MAX,MIN)
    print("vetor",xbest,"funcao", Fun.Fun(xbest),"\n")
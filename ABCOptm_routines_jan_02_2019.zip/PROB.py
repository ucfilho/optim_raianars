'''
probablilidade usada para roleta q atualizacao das onlookers
semelhante ao genetico
'''

import FIT
import numpy as np

def PROB(x):
    rows=x.shape[0]
    fit=np.zeros(rows)
    prob=np.zeros(rows)
    fit=FIT.FIT(x)
    soma=np.sum(fit)

    for i in range(rows):
        prob[i] = fit[i]/soma

    return prob
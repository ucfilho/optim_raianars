
'''
Metodo que alterna e coordena o uso employers,onlooker, scout bees
e greedy search

'''
import Fun
import Enxame
import PROB
import GetBest
import EmployedBee
import OnlookerBee
import ScoutBee
import numpy as np

def ABC(ITE,PAR,ntrail,NPAR,MAX,MIN):

    trial=1 # inicializa contador p abandonar fonte de alimento
    xbest=Enxame.Enxame(PAR,1,MAX,MIN)[0,] #inicializa xbest
    xo=Enxame.Enxame(PAR,NPAR,MAX,MIN) # inicializa employed bee-parte 1
    vbest_old=Fun.Fun(xbest)
    vbest_new=Fun.Fun(xbest)

    for i in range(ITE):
      x=Enxame.Enxame(PAR,NPAR,MAX,MIN) # inicializa employed bee-parte 1
      if(vbest_new==vbest_old):
        trial=trial+1
      if(trial==ntrail):
        xo=Enxame.Enxame(PAR,NPAR,MAX,MIN) # abandona a fonte de alimento antiga
        trial=0
      x_Employed=EmployedBee.EmployedBee(xo,x,MAX,MIN)
      xbest=GetBest.GetBest(x_Employed,xbest)
      vbest_new=Fun.Fun(xbest)
      xo=Enxame.Enxame(PAR,NPAR,MAX,MIN) # inicializa OnlookerBee
      x_Onlooker=OnlookerBee.OnlookerBee(xo,x_Employed)
      xbest=GetBest.GetBest(x_Onlooker,xbest)
      x_Scout=Enxame.Enxame(PAR,NPAR,MAX,MIN) # inicializa ScoutBee ( a rigor so esta linha basta)
      xbest=GetBest.GetBest(x_Scout,xbest)
    return xbest
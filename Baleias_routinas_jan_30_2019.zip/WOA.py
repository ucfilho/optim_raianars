import BEST, New_X, Enxame, Fun


def WOA(ITE,PAR,NPAR,MAX,MIN): # realiza todas interacoes do WOA
  k=1 #contador de iteracoes
  x=Enxame.Enxame(PAR,NPAR,MAX,MIN) # inicializa baleias
  Best=BEST.BEST(x)
  while(k<=ITE):
    x=New_X.New_X(k,ITE,PAR,NPAR,MAX,MIN,Best,x) # atualiza baleias
    k=k+1 # atualiza iteracoes
    Best=BEST.BEST(x) # atualiza melhor baleia
  
  ycal=Fun.Fun(Best)
  return Best,ycal

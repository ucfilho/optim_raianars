import FIT, FOBJ

# retorna o best X*
def BEST(x):
  ycal=FOBJ.FOBJ(x)
  Ind=FIT.FIT(ycal) # ajusta para encontrar o indice dos os lobos alfa, beta e delta
  Best=x[Ind[0],]
  return Best

''' 
Fit ordena os vetores do que fornece MIN a MAX valor de FOBJ : 
        eh necessario para encontrar alfa, beta e delta (lobos)
'''
import numpy as np

def FIT(X):
    fit=np.argsort(X)
    return fit

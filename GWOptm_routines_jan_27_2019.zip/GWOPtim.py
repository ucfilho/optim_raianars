import numpy as np
import Enxame
import Alfa_Beta_Delta
import New_X
import Fun
def GWOPtim(PAR,ITE,NPAR,MAX,MIN):
  k=1 #contador de iteracoes
  x=Enxame.Enxame(PAR,NPAR,MAX,MIN) # inicializa lobos
  Alfa,Beta,Delta=Alfa_Beta_Delta.Alfa_Beta_Delta(x)
  while(k<=ITE):
    k=k+1 # atualiza iteracoes
    x=New_X.New_X(k,ITE,PAR,NPAR,Alfa,Beta,Delta,x) # atualiza lobos
    Alfa,Beta,Delta=Alfa_Beta_Delta.Alfa_Beta_Delta(x) # atualiza alfa,beta e delta...
  return Alfa

# atualiza a matriz de populacoes

import Matriz_AC
import numpy as np

def New_X(k,ITE,PAR,NPAR,Alfa,Beta,Delta,X):
  a=2*(k-ITE)/(1-ITE) # parametro que varia de 2 a zero linermente: gera espiral
  A1,C1=Matriz_AC.Matriz_AC(a,PAR,NPAR)# matriz da espiral e matrix aletoria range dobro
  A2,C2=Matriz_AC.Matriz_AC(a,PAR,NPAR) # idem A1,C1
  A3,C3=Matriz_AC.Matriz_AC(a,PAR,NPAR) # idem A1,C1
  X1=np.zeros((NPAR, PAR)) # sera utilizado com base no alfa
  X2=np.zeros((NPAR, PAR)) # sera utilizado com base no beta
  X3=np.zeros((NPAR, PAR)) # sera utilizado com base no delta
  for j in range(PAR):
    for i in range(NPAR):
      D1=abs(Alfa[j]*C1[i,j]-X[i,j])
      D2=abs(Beta[j]*C2[i,j]-X[i,j])
      D3=abs(Delta[j]*C3[i,j]-X[i,j])
      X1=Alfa[j]-A1[i,j]*D1
      X2=Beta[j]-A2[i,j]*D2
      X3=Delta[j]-A3[i,j]*D3
      X[i,j]=(X1+X2+X3)/3  # posicao provavel da presa q cada lobo enxerga
  return X
  

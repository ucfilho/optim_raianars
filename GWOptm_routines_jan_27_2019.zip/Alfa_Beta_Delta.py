# retorna quem sao os lobos alfa, beta e delta
import FOBJ
import FIT
import Fun

def Alfa_Beta_Delta(x):
  ycal=FOBJ.FOBJ(x)
  Ind=FIT.FIT(ycal) # ajusta para encontrar o indice dos os lobos alfa, beta e delta
  Alfa=x[Ind[0],]
  Beta=x[Ind[1],]
  Delta=x[Ind[2],]
  return Alfa,Beta,Delta


import numpy as np
from random import randint

import Alfa_Beta_Delta
import Fun
import New_X
import Fun
import Enxame
import FOBJ
import FIT
import Matriz_AC
import GWOPtim

"""
Created on Sunday Jan 27 2019
@author: ucfilho
"""

NPAR=200 #Lobos
ITE=50 #ITERACOES
PAR=2 #NUM DE PARAMETROS A SER OTIMIZADOS
MAX=[2,2] # MAXIMO DE CADA PARAMETRO
MIN=[-2,-2] # MINIMO DE CADA PARAMETRO
Alfa=GWOPtim.GWOPtim(PAR,ITE,NPAR,MAX,MIN) # melhor solucao
ycal=Fun.Fun(Alfa) # VALOR DA FUNCAO NA MELHOR SOLUCAO

print("Lobos=",NPAR,"      Iteracoes=",ITE,"   x=",Alfa,"       fobj=",ycal,"\n")


